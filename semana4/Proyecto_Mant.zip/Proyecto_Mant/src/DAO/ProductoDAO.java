package DAO;
public class ProductoDAO {
    public ProductoDAO() {
    }
    //Proceso de visualización(Select)
    
    //Proceso de inserción(Insert)
    
    //Proceso de actualización(update)
    
    //Proceso de eliminación(Delete)
    

}
