package PRUEBA;

import BEAN.Producto;
import DAO.Categoria;

public class Test {
    public static void main(String args[]){
        Categoria catComputo;
        catComputo = new Categoria(1001, "Computo", "Todo computo");
        Categoria catFerreteria;
        catFerreteria = new Categoria(1002, "Ferrteria", "Todo ferreteria");
        
        Producto prodLaptop;
        prodLaptop = new Producto(101, "Laptop HP", catComputo, 1500.5);
        
        System.out.println(prodLaptop.repDatos());
        
        
        
    }
    
}
