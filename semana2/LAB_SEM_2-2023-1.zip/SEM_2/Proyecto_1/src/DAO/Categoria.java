package DAO;
public class Categoria {
    private int idCategoria;
    private String descCat;
    private String obs;

    public Categoria() {
    }

    public Categoria(int idCategoria, String descCat, String obs) {
        this.idCategoria = idCategoria;
        this.descCat = descCat;
        this.obs = obs;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getDescCat() {
        return descCat;
    }

    public void setDescCat(String descCat) {
        this.descCat = descCat;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }
    
    
    
    
    
    public String repDatos(){
        String aux;
        aux = "\nId Categoria: "+this.idCategoria;
        aux += "\nDescripción categoría: "+this.descCat;
        aux += "\nObservaciones: "+this.obs;
        return aux;
    }
    
}
