package BEAN;

import DAO.Categoria;

public class Producto {
    private int idProducto;
    private String descProd;
    private Categoria cate;
    private double precio;

    public Producto() {
    }

    public Producto(int idProducto, String descProd, Categoria cate, double precio) {
        this.idProducto = idProducto;
        this.descProd = descProd;
        this.cate = cate;
        this.precio = precio;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getDescProd() {
        return descProd;
    }

    public void setDescProd(String descProd) {
        this.descProd = descProd;
    }

    public Categoria getCate() {
        return cate;
    }

    public void setCate(Categoria cate) {
        this.cate = cate;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    
    
    
    public String repDatos(){
        String aux;
        aux = "Id Producto: "+this.idProducto;
        aux += "\nDescripción producto: "+this.descProd;
        aux += "\n=======DETALLE CATEGORÌA========";
        aux += this.cate.repDatos();
        aux += "\n=========================";
        aux += "\nPrecio: "+this.precio;
        return aux;
    }
    
    
    
}
