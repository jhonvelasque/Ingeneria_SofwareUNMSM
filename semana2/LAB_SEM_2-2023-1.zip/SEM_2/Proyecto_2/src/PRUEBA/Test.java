package PRUEBA;

import BEAN.Producto;
import DAO.ProductoDAO;

public class Test {
    public static void main(String args[]){
        ProductoDAO prodDao = new ProductoDAO();
        
        Producto prodLaptop = new Producto(101, "Laptop HP",1500, "Computo");
        Producto prodImpresora = new Producto(102, "Impresora epson",100, "Computo");
        Producto prodTaladro = new Producto(103, "Taladro Boch",150, "Ferretería");
        
        prodDao.agregaProducto(prodLaptop);
        prodDao.agregaProducto(prodImpresora);
        prodDao.agregaProducto(prodTaladro);
        
        prodDao.repVectorPro();
        
        
    }
    
}
