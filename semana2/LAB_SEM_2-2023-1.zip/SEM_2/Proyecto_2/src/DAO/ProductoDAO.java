
package DAO;

import BEAN.Producto;
import java.util.Vector;

public class ProductoDAO {
    private Vector vecProd;
    
    public ProductoDAO(){
        vecProd = new Vector();
    }
    
    public void agregaProducto(Producto prod){
        vecProd.addElement(prod);
    }
    
    public void repVectorPro(){
        Producto prod;
        for(int i=0;i<vecProd.size();i++){
            prod = (Producto)vecProd.get(i);
            System.out.println(prod.repDatos());
            System.out.println("==========================");
        }
    }
    
    
    
    
    
    
}
