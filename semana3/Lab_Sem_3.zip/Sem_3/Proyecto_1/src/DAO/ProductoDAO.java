package DAO;

import BEAN.Producto;
import java.util.Vector;

public class ProductoDAO {
    private Vector vecProd;

    public ProductoDAO(){
        vecProd = new Vector();
    }
    
    public void agregaProducto(Producto p){
        this.vecProd.addElement(p);
    }
    
    public void reportarProducto(){
        Producto prod;
        for(int i =0;i<vecProd.size();i++){
            prod = (Producto)vecProd.get(i);
            System.out.println(prod.repDatos());
            System.out.println("==========================");
        }
    }
    public void reportaPorTipo(String tip){
        Producto prod;
        for(int i=0;i<vecProd.size();i++){
            prod = (Producto)vecProd.get(i);
            if(prod.getTipo().equals(tip)){
                System.out.println(prod.repDatos());
                System.out.println("==========================");
            }
        }
    }
    
    
    
    
    
}
