
package IU;

import BEAN.Empleado;
import BEAN.TipoEmp;
import DAO.EmpleadoDAO;
import DAO.TipEmpDAO;
import UTIL.Util;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;

public class FrmEmpleado extends javax.swing.JFrame {
    TipEmpDAO tipEmpDao;
    DefaultTableModel dtm;
    EmpleadoDAO empDao;
    public FrmEmpleado() {
        initComponents();
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        tipEmpDao = new TipEmpDAO();
        empDao = new EmpleadoDAO();
        dtm = (DefaultTableModel)this.tblEmpleados.getModel();
        llenaCmbEstado();
        llenaCmbTipEmp();
    }
    private void llenaCmbTipEmp(){
        Vector<TipoEmp> listaTipEmp;
        listaTipEmp =tipEmpDao.listaTip();
        this.cmbTipEmp.addItem("");
        for(int i=0;i<listaTipEmp.size();i++){
            this.cmbTipEmp.addItem(listaTipEmp.get(i).getDescTip());
        }
    }
    private void llenaCmbEstado(){
        this.cmbEstado.addItem("");
        this.cmbEstado.addItem("Activo");
        this.cmbEstado.addItem("No Activo");
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtIdEmpleado = new javax.swing.JTextField();
        txtApellidos = new javax.swing.JTextField();
        TxtNombres = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        rbFemenino = new javax.swing.JRadioButton();
        rbMasculino = new javax.swing.JRadioButton();
        jPanel3 = new javax.swing.JPanel();
        cbAfp = new javax.swing.JCheckBox();
        cbSeguro = new javax.swing.JCheckBox();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cmbTipEmp = new javax.swing.JComboBox();
        cmbEstado = new javax.swing.JComboBox();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblEmpleados = new javax.swing.JTable();
        btnAgrega = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel2.setLayout(null);

        jLabel1.setText("Id_Empleado");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(40, 40, 70, 14);

        jLabel2.setText("Apellidos");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(40, 80, 60, 14);

        jLabel3.setText("Nombres");
        jPanel2.add(jLabel3);
        jLabel3.setBounds(40, 110, 50, 14);
        jPanel2.add(txtIdEmpleado);
        txtIdEmpleado.setBounds(120, 40, 80, 20);
        jPanel2.add(txtApellidos);
        txtApellidos.setBounds(120, 80, 240, 20);
        jPanel2.add(TxtNombres);
        TxtNombres.setBounds(120, 110, 240, 20);

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Sexo"));
        jPanel4.setLayout(null);

        buttonGroup1.add(rbFemenino);
        rbFemenino.setText("Femenino");
        jPanel4.add(rbFemenino);
        rbFemenino.setBounds(30, 20, 110, 23);

        buttonGroup1.add(rbMasculino);
        rbMasculino.setText("Masculino");
        jPanel4.add(rbMasculino);
        rbMasculino.setBounds(180, 20, 110, 23);

        jPanel2.add(jPanel4);
        jPanel4.setBounds(40, 140, 320, 50);

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        jPanel3.setLayout(null);

        cbAfp.setText("AFP");
        jPanel3.add(cbAfp);
        cbAfp.setBounds(40, 20, 81, 23);

        cbSeguro.setText("Seguro");
        jPanel3.add(cbSeguro);
        cbSeguro.setBounds(170, 20, 59, 23);

        jPanel2.add(jPanel3);
        jPanel3.setBounds(40, 200, 320, 50);

        jLabel4.setText("Tipo empleado");
        jPanel2.add(jLabel4);
        jLabel4.setBounds(30, 290, 110, 14);

        jLabel5.setText("Estado");
        jPanel2.add(jLabel5);
        jLabel5.setBounds(30, 330, 70, 14);

        jPanel2.add(cmbTipEmp);
        cmbTipEmp.setBounds(150, 290, 140, 20);

        jPanel2.add(cmbEstado);
        cmbEstado.setBounds(150, 330, 140, 20);

        jTabbedPane1.addTab("Mantenimiento", jPanel2);

        getContentPane().add(jTabbedPane1);
        jTabbedPane1.setBounds(30, 40, 400, 490);

        jPanel5.setLayout(null);

        tblEmpleados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Apellidos", "Nombres", "Sexo", "AFP", "Seguro", "Tipo", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblEmpleados);

        jPanel5.add(jScrollPane1);
        jScrollPane1.setBounds(10, 20, 480, 330);

        getContentPane().add(jPanel5);
        jPanel5.setBounds(550, 60, 510, 400);

        btnAgrega.setText("Agrega");
        btnAgrega.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregaActionPerformed(evt);
            }
        });
        getContentPane().add(btnAgrega);
        btnAgrega.setBounds(450, 240, 67, 23);

        jButton1.setText("Grabar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(640, 480, 93, 23);

        jButton2.setText("Salir");
        getContentPane().add(jButton2);
        jButton2.setBounds(770, 480, 100, 23);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgregaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregaActionPerformed
        Vector vec = new Vector();
        vec.addElement(this.txtApellidos.getText());
        vec.addElement(this.TxtNombres.getText());
        if(this.rbFemenino.isSelected()){
            vec.addElement("Femenino");
        }else{
            vec.addElement("Masculino");
        }
        if(this.cbAfp.isSelected()){
            vec.addElement("Sí");
        }else{
            vec.addElement("No");
        }
        if(this.cbSeguro.isSelected()){
            vec.addElement("Sí");
        }else{
            vec.addElement("No");
        }
        vec.addElement(this.cmbTipEmp.getSelectedItem().toString());
        vec.addElement(this.cmbEstado.getSelectedItem().toString());
        dtm.addRow(vec);
    }//GEN-LAST:event_btnAgregaActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Util u = new Util();
        int idTipEmp;
        int idEmp;
        String descTip;
        for(int i=0;i<dtm.getRowCount();i++){
            Empleado emp = new Empleado();
            idEmp = u.idNext("Empleado", "Id_Empleado");
            emp.setId_Empleado(idEmp);
            emp.setApellidos(dtm.getValueAt(i, 0).toString());
            emp.setNombres(dtm.getValueAt(i, 1).toString());
            if(dtm.getValueAt(i, 2).toString().equals("Femenino")){
                emp.setSexo(0);
            }else{
                emp.setSexo(1);
            }
            if(dtm.getValueAt(i, 3).toString().equals("Sí")){
                emp.setAfp(1);
            }else{
                emp.setAfp(0);
            }
            if(dtm.getValueAt(i, 4).toString().equals("Sí")){
                emp.setSeguro(1);
            }else{
                emp.setSeguro(0);
            }
            descTip = dtm.getValueAt(i, 5).toString();
            idTipEmp = this.tipEmpDao.devuelveIdTipEmp(descTip);
            emp.setTipo(idTipEmp);
            if(dtm.getValueAt(i, 6).toString().equals("Activo")){
                emp.setEstado(1);
            }else{
                emp.setEstado(0);
            }
            this.empDao.procesaEmp(emp, "insert");
        }
        
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmEmpleado().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField TxtNombres;
    private javax.swing.JButton btnAgrega;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JCheckBox cbAfp;
    private javax.swing.JCheckBox cbSeguro;
    private javax.swing.JComboBox cmbEstado;
    private javax.swing.JComboBox cmbTipEmp;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JRadioButton rbFemenino;
    private javax.swing.JRadioButton rbMasculino;
    private javax.swing.JTable tblEmpleados;
    private javax.swing.JTextField txtApellidos;
    private javax.swing.JTextField txtIdEmpleado;
    // End of variables declaration//GEN-END:variables
}
