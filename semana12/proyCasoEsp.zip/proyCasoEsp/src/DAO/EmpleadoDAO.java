package DAO;

import BEAN.Empleado;
import UTIL.DbBean;
import java.sql.ResultSet;
import java.util.Vector;

public class EmpleadoDAO {
    public Vector<Empleado> listEmpleados(boolean swr, String cadr){
        Vector<Empleado> lista = new Vector<Empleado>();
        DbBean con = new DbBean();
        String sql = "Select * from empleado ";
        if(swr == true){
            sql = sql + " where (apellidos like '"+ cadr +"' or nombres like '"+ cadr +"')";
        }
        try{
            ResultSet resultado = con.resultadoSQL(sql);
            while(resultado.next()){
                Empleado emp = new Empleado();
                emp.setId_Empleado(resultado.getInt(1));
                emp.setApellidos(resultado.getString(2));
                emp.setNombres(resultado.getString(3));
                emp.setSexo(resultado.getInt(4));
                emp.setAfp(resultado.getInt(5));
                emp.setSeguro(resultado.getInt(6));
                emp.setTipo(resultado.getInt(7));
                emp.setEstado(resultado.getInt(8));
                lista.addElement(emp);
            }
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
        try{
            con.desconecta();
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
        return lista;
    }
    
    public int procesaEmp(Empleado emp, String proc){
        int resultado = 0;
        String sql = "";
        DbBean con = new DbBean();
        if(proc.equals("insert")){
            
            int ie;
            String a, n;
            int s, af, seg, tip, es;
            ie = emp.getId_Empleado();
            a = emp.getApellidos();
            n = emp.getNombres();
            s = emp.getSexo();
            af = emp.getAfp();
            seg = emp.getSeguro();
            tip = emp.getTipo();
            es = emp.getEstado();
                    
            sql = "insert into empleado values ('"+ ie +"', '"+ a +"', +"+ n +"', '"+ s +"', '"+  af +"', '"+ seg +"', '"+ tip +"', '"+ es +"' )";
            try{
                resultado = con.ejecutaSQL(sql);
            }catch(java.sql.SQLException e){
                e.printStackTrace();
            }
            try{
                con.desconecta();
            }catch(java.sql.SQLException e){
                e.printStackTrace();
            }
        }
        
        return resultado;
    }
    
}
