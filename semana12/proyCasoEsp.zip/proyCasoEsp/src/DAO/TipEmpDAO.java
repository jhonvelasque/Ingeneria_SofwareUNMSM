package DAO;

import BEAN.TipoEmp;
import UTIL.DbBean;
import java.sql.ResultSet;
import java.util.Vector;

public class TipEmpDAO {
    public Vector<TipoEmp> listaTip(){
        DbBean con = new DbBean();
        Vector<TipoEmp> lista = new Vector<TipoEmp>();
        String sql = "Select * from TipoEmp";
        try{
            ResultSet resultado = con.resultadoSQL(sql);
            while(resultado.next()){
                TipoEmp te = new TipoEmp();
                te.setId_Tipo(resultado.getInt(1));
                te.setDescTip(resultado.getString(2));
                lista.addElement(te);
            }
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
        return lista;
    }
}
