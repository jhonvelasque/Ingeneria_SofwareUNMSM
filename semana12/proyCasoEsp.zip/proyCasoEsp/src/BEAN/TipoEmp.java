package BEAN;
public class TipoEmp {
    private int Id_Tipo;
    private String DescTip;

    public TipoEmp() {
    }

    public TipoEmp(int Id_Tipo, String DescTip) {
        this.Id_Tipo = Id_Tipo;
        this.DescTip = DescTip;
    }

    public int getId_Tipo() {
        return Id_Tipo;
    }

    public void setId_Tipo(int Id_Tipo) {
        this.Id_Tipo = Id_Tipo;
    }

    public String getDescTip() {
        return DescTip;
    }

    public void setDescTip(String DescTip) {
        this.DescTip = DescTip;
    }
    
    
    
}
