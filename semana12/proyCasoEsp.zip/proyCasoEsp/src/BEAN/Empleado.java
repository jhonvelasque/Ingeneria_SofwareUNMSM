package BEAN;

public class Empleado {
    private int Id_Empleado;
    private String Apellidos;
    private String Nombres;
    private int sexo;
    private int afp;
    private int seguro;
    private int tipo;
    private int estado;

    public Empleado() {
    }

    public Empleado(int Id_Empleado, String Apellidos, String Nombres, int sexo, int afp, int seguro, int tipo, int estado) {
        this.Id_Empleado = Id_Empleado;
        this.Apellidos = Apellidos;
        this.Nombres = Nombres;
        this.sexo = sexo;
        this.afp = afp;
        this.seguro = seguro;
        this.tipo = tipo;
        this.estado = estado;
    }

    public int getId_Empleado() {
        return Id_Empleado;
    }

    public void setId_Empleado(int Id_Empleado) {
        this.Id_Empleado = Id_Empleado;
    }

    public String getApellidos() {
        return Apellidos;
    }

    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos;
    }

    public String getNombres() {
        return Nombres;
    }

    public void setNombres(String Nombres) {
        this.Nombres = Nombres;
    }

    public int getSexo() {
        return sexo;
    }

    public void setSexo(int sexo) {
        this.sexo = sexo;
    }

    public int getAfp() {
        return afp;
    }

    public void setAfp(int afp) {
        this.afp = afp;
    }

    public int getSeguro() {
        return seguro;
    }

    public void setSeguro(int seguro) {
        this.seguro = seguro;
    }

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }
    
    
    
    
           
}
